package org;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * preprocess the sentences from all column of 0_raw file and create a new table _1_preprocess.
 * data: language data such as java, pharo, and python.
 * preprocessing conditions: allow only letter & digit, atmost 400 chars
 */
public class T1Preprocessor{
    private final String database;
    private final String data;


    public T1Preprocessor(String database, String data) {
        this.database = database;
        this.data = data;
    }

    public void run() throws SQLException {
        try (
                Connection connection = DriverManager.getConnection(this.database);
                Statement statement = connection.createStatement()
        ) {
            statement.executeUpdate("PRAGMA foreign_keys = on");
            statement.executeUpdate("CREATE TABLE " + this.data + "_1_preprocessed AS SELECT * FROM " + this.data + "_0_raw WHERE 1 = 0");
            List<String> categories = this.categories(statement);
            try (
                    ResultSet result = statement.executeQuery("SELECT * FROM " + this.data + "_0_raw");
                    PreparedStatement insert = this.insert(connection, categories)
            ) {
                while (result.next()) {
                    String clazz = result.getString("class");
                    int stratum = result.getInt("stratum");
                    String comment = result.getString("comment");
                    insert.setString(1, clazz);
                    insert.setInt(2, stratum);
                    insert.setString(3, InstancesBuilder.preprocess(comment));
                    for (int i = 0; i < categories.size(); i = i + 1) {
                        insert.setString(4+i, InstancesBuilder.preprocess(result.getString(4+i)));
                    }
                    insert.executeUpdate();
                }
            }
        }
    }

    public void doNotRun(){
    }

    /**
     * prepare db insert statement to insert values
     * @param connection database connection
     * @param categories all columns except class, startum, and comment column or taxonomy categories
     * @return sql query to insert values
     * @throws SQLException
     */
    private PreparedStatement insert(Connection connection, List<String> categories) throws SQLException {
        return connection.prepareStatement(
                "INSERT INTO " + this.data + "_1_preprocessed ( class, stratum, comment," + String.join(",",
                        categories.stream().map(c -> String.format("\"%s\"", c)).collect( Collectors.toList())
                ) + ") VALUES (?, ?, ?, "+ String.join(",",
                        categories.stream().map(c -> "?").collect(Collectors.toList())
                ) + ")");
    }

    /**
     * access the categories from raw table
     * @param statement sql statement
     * @return return all the taxonomy categories except class, startum, and comment column
     * @throws SQLException
     */
    private List<String> categories(Statement statement) throws SQLException {
        List<String> categories = new ArrayList<>();
        try (
                //ResultSet result = statement.executeQuery(
                //        "SELECT name FROM PRAGMA_TABLE_INFO('" + this.data + "_0_raw')")
                ResultSet result = statement.executeQuery("SELECT * FROM " + this.data + "_0_raw")
        ) {
            ResultSetMetaData rsmd = result.getMetaData();
            for(int i = 1; i <= rsmd.getColumnCount(); i++){
                categories.add(rsmd.getColumnName( i ));
            }
/*            while (result.next()) {
                categories.add(result.getString("name"));
            }*/
        }
        categories.remove("class");
        categories.remove("stratum");
        categories.remove("comment");
        return categories;
    }
}
